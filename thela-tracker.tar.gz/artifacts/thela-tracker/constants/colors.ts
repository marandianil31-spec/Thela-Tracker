const teal = "#0D7377";
const tealLight = "#14A085";
const orange = "#F76C3D";
const orangeLight = "#FF8A60";

export default {
  light: {
    text: "#1A1A2E",
    textSecondary: "#6B7280",
    background: "#F5F7FA",
    card: "#FFFFFF",
    tint: teal,
    tintLight: tealLight,
    accent: orange,
    accentLight: orangeLight,
    tabIconDefault: "#9CA3AF",
    tabIconSelected: teal,
    border: "#E5E7EB",
    inputBackground: "#F9FAFB",
    success: "#10B981",
    error: "#EF4444",
    mapPlaceholder: "#E8F5F5",
  },
};
