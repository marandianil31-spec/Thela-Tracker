import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

export type VendorType =
  | "Food"
  | "Vegetables"
  | "Fruits"
  | "Snacks"
  | "Clothing"
  | "Electronics"
  | "Other";

export interface Vendor {
  id: string;
  name: string;
  type: VendorType;
  phone: string;
  createdAt: string;
  location?: string;
}

interface VendorContextType {
  vendors: Vendor[];
  loading: boolean;
  addVendor: (vendor: Omit<Vendor, "id" | "createdAt">) => Promise<void>;
  deleteVendor: (id: string) => Promise<void>;
  updateVendor: (id: string, updates: Partial<Omit<Vendor, "id" | "createdAt">>) => Promise<void>;
}

const STORAGE_KEY = "@thela_tracker_vendors";

const VendorContext = createContext<VendorContextType | null>(null);

export function VendorProvider({ children }: { children: React.ReactNode }) {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVendors();
  }, []);

  const loadVendors = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        setVendors(JSON.parse(stored));
      }
    } catch (e) {
    } finally {
      setLoading(false);
    }
  };

  const saveVendors = async (updated: Vendor[]) => {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const addVendor = useCallback(
    async (vendor: Omit<Vendor, "id" | "createdAt">) => {
      const newVendor: Vendor = {
        ...vendor,
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        createdAt: new Date().toISOString(),
      };
      const updated = [...vendors, newVendor];
      setVendors(updated);
      await saveVendors(updated);
    },
    [vendors]
  );

  const deleteVendor = useCallback(
    async (id: string) => {
      const updated = vendors.filter((v) => v.id !== id);
      setVendors(updated);
      await saveVendors(updated);
    },
    [vendors]
  );

  const updateVendor = useCallback(
    async (id: string, updates: Partial<Omit<Vendor, "id" | "createdAt">>) => {
      const updated = vendors.map((v) =>
        v.id === id ? { ...v, ...updates } : v
      );
      setVendors(updated);
      await saveVendors(updated);
    },
    [vendors]
  );

  return (
    <VendorContext.Provider
      value={{ vendors, loading, addVendor, deleteVendor, updateVendor }}
    >
      {children}
    </VendorContext.Provider>
  );
}

export function useVendors() {
  const ctx = useContext(VendorContext);
  if (!ctx) throw new Error("useVendors must be used within VendorProvider");
  return ctx;
}
