import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { VendorType, useVendors } from "@/context/VendorContext";

const VENDOR_TYPES: VendorType[] = [
  "Food",
  "Vegetables",
  "Fruits",
  "Snacks",
  "Clothing",
  "Electronics",
  "Other",
];

const TYPE_ICONS: Record<string, string> = {
  Food: "coffee",
  Vegetables: "feather",
  Fruits: "sun",
  Snacks: "star",
  Clothing: "tag",
  Electronics: "zap",
  Other: "package",
};

const TYPE_COLORS: Record<string, string> = {
  Food: "#F76C3D",
  Vegetables: "#10B981",
  Fruits: "#F59E0B",
  Snacks: "#8B5CF6",
  Clothing: "#EC4899",
  Electronics: "#3B82F6",
  Other: "#6B7280",
};

export default function AddScreen() {
  const { addVendor } = useVendors();
  const insets = useSafeAreaInsets();
  const colors = Colors.light;

  const isWeb = Platform.OS === "web";
  const topInset = isWeb ? 0 : insets.top;
  const bottomInset = isWeb ? 34 : insets.bottom;

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [selectedType, setSelectedType] = useState<VendorType>("Food");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});

  const validate = () => {
    const newErrors: { name?: string; phone?: string } = {};
    if (!name.trim()) newErrors.name = "Vendor name is required";
    else if (name.trim().length < 2) newErrors.name = "Name must be at least 2 characters";
    if (!phone.trim()) newErrors.phone = "Phone number is required";
    else if (!/^[+\d\s\-()]{7,15}$/.test(phone.trim()))
      newErrors.phone = "Enter a valid phone number";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    setLoading(true);
    try {
      await addVendor({
        name: name.trim(),
        type: selectedType,
        phone: phone.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setName("");
      setPhone("");
      setSelectedType("Food");
      setErrors({});
      router.push("/(tabs)/list");
    } catch {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { paddingTop: topInset + 12, backgroundColor: colors.card },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.text }]}>
          Add Vendor
        </Text>
        <Text style={[styles.headerSub, { color: colors.textSecondary }]}>
          Track a new thela vendor
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.form,
          { paddingBottom: bottomInset + 120 },
        ]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.section}>
          <Text style={[styles.label, { color: colors.text }]}>
            Vendor Name
          </Text>
          <View
            style={[
              styles.inputWrapper,
              {
                backgroundColor: colors.card,
                borderColor: errors.name ? colors.error : colors.border,
              },
            ]}
          >
            <Feather
              name="user"
              size={18}
              color={errors.name ? colors.error : colors.textSecondary}
              style={styles.inputIcon}
            />
            <TextInput
              value={name}
              onChangeText={(t) => {
                setName(t);
                if (errors.name) setErrors((e) => ({ ...e, name: undefined }));
              }}
              placeholder="e.g. Ramesh Sabziwala"
              placeholderTextColor={colors.textSecondary + "99"}
              style={[styles.input, { color: colors.text }]}
              returnKeyType="next"
            />
          </View>
          {errors.name && (
            <Text style={[styles.errorText, { color: colors.error }]}>
              {errors.name}
            </Text>
          )}
        </View>

        <View style={styles.section}>
          <Text style={[styles.label, { color: colors.text }]}>
            Phone Number
          </Text>
          <View
            style={[
              styles.inputWrapper,
              {
                backgroundColor: colors.card,
                borderColor: errors.phone ? colors.error : colors.border,
              },
            ]}
          >
            <Feather
              name="phone"
              size={18}
              color={errors.phone ? colors.error : colors.textSecondary}
              style={styles.inputIcon}
            />
            <TextInput
              value={phone}
              onChangeText={(t) => {
                setPhone(t);
                if (errors.phone)
                  setErrors((e) => ({ ...e, phone: undefined }));
              }}
              placeholder="e.g. 9876543210"
              placeholderTextColor={colors.textSecondary + "99"}
              style={[styles.input, { color: colors.text }]}
              keyboardType="phone-pad"
              returnKeyType="done"
            />
          </View>
          {errors.phone && (
            <Text style={[styles.errorText, { color: colors.error }]}>
              {errors.phone}
            </Text>
          )}
        </View>

        <View style={styles.section}>
          <Text style={[styles.label, { color: colors.text }]}>
            Vendor Type
          </Text>
          <View style={styles.typeGrid}>
            {VENDOR_TYPES.map((type) => {
              const active = selectedType === type;
              const color = TYPE_COLORS[type];
              const icon = TYPE_ICONS[type];
              return (
                <Pressable
                  key={type}
                  onPress={() => {
                    Haptics.selectionAsync();
                    setSelectedType(type);
                  }}
                  style={({ pressed }) => [
                    styles.typeCard,
                    {
                      backgroundColor: active ? color : colors.card,
                      borderColor: active ? color : colors.border,
                      opacity: pressed ? 0.85 : 1,
                      transform: [{ scale: pressed ? 0.97 : 1 }],
                    },
                  ]}
                >
                  <Feather
                    name={icon as any}
                    size={20}
                    color={active ? "#fff" : color}
                  />
                  <Text
                    style={[
                      styles.typeLabel,
                      { color: active ? "#fff" : colors.text },
                    ]}
                  >
                    {type}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        <Pressable
          onPress={handleSubmit}
          disabled={loading}
          style={({ pressed }) => [
            styles.submitButton,
            {
              backgroundColor: colors.tint,
              opacity: pressed || loading ? 0.85 : 1,
              transform: [{ scale: pressed ? 0.98 : 1 }],
            },
          ]}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Feather name="check-circle" size={20} color="#fff" />
              <Text style={styles.submitText}>Save Vendor</Text>
            </>
          )}
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 2,
    zIndex: 10,
  },
  headerTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
  },
  headerSub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginTop: 3,
  },
  form: {
    padding: 20,
    gap: 24,
  },
  section: {
    gap: 10,
  },
  label: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.2,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1.5,
    paddingHorizontal: 14,
    height: 52,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  errorText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: -4,
  },
  typeGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  typeCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1.5,
    minWidth: "44%",
  },
  typeLabel: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
  submitButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    borderRadius: 16,
    paddingVertical: 16,
    shadowColor: "#0D7377",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
    marginTop: 8,
  },
  submitText: {
    color: "#fff",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
});
