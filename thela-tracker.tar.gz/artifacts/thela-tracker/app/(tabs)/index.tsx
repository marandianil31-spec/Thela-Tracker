import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  Platform,
  StyleSheet,
  Text,
  View,
  useColorScheme,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { useVendors } from "@/context/VendorContext";

const TYPE_ICONS: Record<string, string> = {
  Food: "coffee",
  Vegetables: "feather",
  Fruits: "sun",
  Snacks: "star",
  Clothing: "tag",
  Electronics: "zap",
  Other: "package",
};

const TYPE_COLORS: Record<string, string> = {
  Food: "#F76C3D",
  Vegetables: "#10B981",
  Fruits: "#F59E0B",
  Snacks: "#8B5CF6",
  Clothing: "#EC4899",
  Electronics: "#3B82F6",
  Other: "#6B7280",
};

export default function MapScreen() {
  const insets = useSafeAreaInsets();
  const colorScheme = useColorScheme();
  const { vendors } = useVendors();
  const colors = Colors.light;

  const isWeb = Platform.OS === "web";
  const topInset = isWeb ? 0 : insets.top;
  const bottomInset = isWeb ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { paddingTop: topInset + 12, backgroundColor: colors.card },
        ]}
      >
        <View style={styles.headerContent}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>
            Thela Tracker
          </Text>
          <Text style={[styles.headerSub, { color: colors.textSecondary }]}>
            {vendors.length} vendor{vendors.length !== 1 ? "s" : ""} tracked
          </Text>
        </View>
        <View style={[styles.badge, { backgroundColor: colors.tint }]}>
          <Feather name="map-pin" size={14} color="#fff" />
        </View>
      </View>

      <View
        style={[
          styles.mapPlaceholder,
          { backgroundColor: colors.mapPlaceholder },
        ]}
      >
        <View style={styles.mapGrid}>
          {Array.from({ length: 6 }).map((_, rowIdx) => (
            <View key={rowIdx} style={styles.mapRow}>
              {Array.from({ length: 4 }).map((_, colIdx) => (
                <View
                  key={colIdx}
                  style={[
                    styles.mapBlock,
                    {
                      backgroundColor:
                        (rowIdx + colIdx) % 3 === 0
                          ? "rgba(13,115,119,0.07)"
                          : (rowIdx + colIdx) % 3 === 1
                          ? "rgba(13,115,119,0.04)"
                          : "transparent",
                    },
                  ]}
                />
              ))}
            </View>
          ))}
        </View>

        {vendors.length === 0 ? (
          <View style={styles.mapOverlay}>
            <View
              style={[
                styles.mapIconCircle,
                { backgroundColor: colors.tint + "22" },
              ]}
            >
              <Feather name="map" size={40} color={colors.tint} />
            </View>
            <Text style={[styles.mapTitle, { color: colors.text }]}>
              No vendors yet
            </Text>
            <Text style={[styles.mapSub, { color: colors.textSecondary }]}>
              Add vendors using the + tab to{"\n"}start tracking them here
            </Text>
          </View>
        ) : (
          <View style={styles.mapOverlay}>
            <View style={styles.pinCluster}>
              {vendors.slice(0, 5).map((v, i) => {
                const angle = (i / Math.max(vendors.length, 1)) * 2 * Math.PI;
                const r = 60;
                const x = Math.cos(angle) * r;
                const y = Math.sin(angle) * r;
                const typeColor = TYPE_COLORS[v.type] ?? "#6B7280";
                return (
                  <View
                    key={v.id}
                    style={[
                      styles.mapPin,
                      {
                        left: 130 + x,
                        top: 100 + y,
                        backgroundColor: typeColor,
                      },
                    ]}
                  >
                    <Feather
                      name={
                        (TYPE_ICONS[v.type] as any) ?? "package"
                      }
                      size={12}
                      color="#fff"
                    />
                  </View>
                );
              })}
              {vendors.length > 5 && (
                <View
                  style={[
                    styles.mapPin,
                    styles.mapPinMore,
                    { backgroundColor: colors.tint, left: 130, top: 100 },
                  ]}
                >
                  <Text style={styles.mapPinMoreText}>
                    +{vendors.length - 5}
                  </Text>
                </View>
              )}
            </View>
            <Text style={[styles.mapHint, { color: colors.textSecondary }]}>
              Placeholder map view
            </Text>
          </View>
        )}

        <View
          style={[
            styles.mapBadge,
            { backgroundColor: colors.card, top: topInset + 80 },
          ]}
        >
          <Feather name="navigation" size={14} color={colors.tint} />
          <Text style={[styles.mapBadgeText, { color: colors.tint }]}>
            Live Map (Coming Soon)
          </Text>
        </View>
      </View>

      <View
        style={[
          styles.statsRow,
          { paddingBottom: bottomInset + 100, backgroundColor: colors.card },
        ]}
      >
        {(["Food", "Vegetables", "Fruits", "Other"] as const).map((type) => {
          const count = vendors.filter((v) => v.type === type).length;
          const color = TYPE_COLORS[type];
          return (
            <View key={type} style={styles.statCard}>
              <View
                style={[
                  styles.statIcon,
                  { backgroundColor: color + "22" },
                ]}
              >
                <Feather
                  name={
                    (TYPE_ICONS[type] as any) ?? "package"
                  }
                  size={16}
                  color={color}
                />
              </View>
              <Text style={[styles.statCount, { color: colors.text }]}>
                {count}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>
                {type}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
    zIndex: 10,
  },
  headerContent: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
  },
  headerSub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  badge: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  mapPlaceholder: {
    flex: 1,
    position: "relative",
    overflow: "hidden",
  },
  mapGrid: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  mapRow: {
    flex: 1,
    flexDirection: "row",
  },
  mapBlock: {
    flex: 1,
    borderWidth: 0.5,
    borderColor: "rgba(13,115,119,0.06)",
  },
  mapOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  mapIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  mapTitle: {
    fontSize: 18,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 8,
  },
  mapSub: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 22,
  },
  pinCluster: {
    width: 300,
    height: 240,
    position: "relative",
  },
  mapPin: {
    position: "absolute",
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  mapPinMore: {},
  mapPinMoreText: {
    color: "#fff",
    fontSize: 10,
    fontFamily: "Inter_700Bold",
  },
  mapHint: {
    marginTop: 8,
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  mapBadge: {
    position: "absolute",
    right: 16,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 6,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  mapBadgeText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  statsRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingTop: 16,
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
  },
  statCard: {
    flex: 1,
    alignItems: "center",
    gap: 4,
  },
  statIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 2,
  },
  statCount: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  statLabel: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
  },
});
