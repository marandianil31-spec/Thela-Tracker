import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Colors from "@/constants/colors";
import { Vendor, useVendors } from "@/context/VendorContext";

const TYPE_COLORS: Record<string, string> = {
  Food: "#F76C3D",
  Vegetables: "#10B981",
  Fruits: "#F59E0B",
  Snacks: "#8B5CF6",
  Clothing: "#EC4899",
  Electronics: "#3B82F6",
  Other: "#6B7280",
};

const TYPE_ICONS: Record<string, string> = {
  Food: "coffee",
  Vegetables: "feather",
  Fruits: "sun",
  Snacks: "star",
  Clothing: "tag",
  Electronics: "zap",
  Other: "package",
};

function VendorCard({ vendor, onDelete }: { vendor: Vendor; onDelete: () => void }) {
  const colors = Colors.light;
  const typeColor = TYPE_COLORS[vendor.type] ?? "#6B7280";
  const typeIcon = TYPE_ICONS[vendor.type] ?? "package";

  const handleCall = () => {
    if (!vendor.phone) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const url = `tel:${vendor.phone.replace(/\s/g, "")}`;
    Linking.openURL(url).catch(() => {
      Alert.alert("Error", "Unable to make the call.");
    });
  };

  const handleDelete = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert(
      "Delete Vendor",
      `Remove ${vendor.name} from your list?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: onDelete,
        },
      ]
    );
  };

  const createdDate = new Date(vendor.createdAt).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <View style={[styles.card, { backgroundColor: colors.card }]}>
      <View
        style={[styles.typeIndicator, { backgroundColor: typeColor + "22" }]}
      >
        <Feather name={typeIcon as any} size={22} color={typeColor} />
      </View>
      <View style={styles.cardContent}>
        <Text style={[styles.vendorName, { color: colors.text }]}>
          {vendor.name}
        </Text>
        <View style={styles.metaRow}>
          <View
            style={[styles.typeBadge, { backgroundColor: typeColor + "18" }]}
          >
            <Text style={[styles.typeBadgeText, { color: typeColor }]}>
              {vendor.type}
            </Text>
          </View>
          <Text style={[styles.dateText, { color: colors.textSecondary }]}>
            Added {createdDate}
          </Text>
        </View>
        <Text style={[styles.phoneText, { color: colors.textSecondary }]}>
          {vendor.phone}
        </Text>
      </View>
      <View style={styles.cardActions}>
        <Pressable
          onPress={handleCall}
          style={({ pressed }) => [
            styles.callButton,
            { backgroundColor: Colors.light.tint, opacity: pressed ? 0.85 : 1 },
          ]}
          accessibilityLabel={`Call ${vendor.name}`}
        >
          <Feather name="phone" size={16} color="#fff" />
        </Pressable>
        <Pressable
          onPress={handleDelete}
          style={({ pressed }) => [
            styles.deleteButton,
            {
              backgroundColor: colors.error + "15",
              opacity: pressed ? 0.7 : 1,
            },
          ]}
          accessibilityLabel={`Delete ${vendor.name}`}
        >
          <Feather name="trash-2" size={15} color={colors.error} />
        </Pressable>
      </View>
    </View>
  );
}

export default function ListScreen() {
  const { vendors, deleteVendor, loading } = useVendors();
  const insets = useSafeAreaInsets();
  const colors = Colors.light;
  const isWeb = Platform.OS === "web";
  const topInset = isWeb ? 0 : insets.top;
  const bottomInset = isWeb ? 34 : insets.bottom;

  const [filter, setFilter] = useState<string>("All");
  const categories = ["All", "Food", "Vegetables", "Fruits", "Snacks", "Clothing", "Electronics", "Other"];

  const filtered = filter === "All" ? vendors : vendors.filter((v) => v.type === filter);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { paddingTop: topInset + 12, backgroundColor: colors.card },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.text }]}>Vendors</Text>
        <View
          style={[styles.countPill, { backgroundColor: colors.tint + "18" }]}
        >
          <Text style={[styles.countText, { color: colors.tint }]}>
            {vendors.length}
          </Text>
        </View>
      </View>

      <View
        style={[styles.filterRow, { backgroundColor: colors.card }]}
      >
        <FlatList
          horizontal
          data={categories}
          keyExtractor={(item) => item}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}
          renderItem={({ item }) => {
            const active = filter === item;
            return (
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  setFilter(item);
                }}
                style={[
                  styles.filterChip,
                  {
                    backgroundColor: active
                      ? colors.tint
                      : colors.inputBackground,
                    borderColor: active ? colors.tint : colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    { color: active ? "#fff" : colors.textSecondary },
                  ]}
                >
                  {item}
                </Text>
              </Pressable>
            );
          }}
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.list,
          {
            paddingBottom: bottomInset + 100,
          },
        ]}
        scrollEnabled={!!(filtered.length > 0)}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <View
              style={[
                styles.emptyIconCircle,
                { backgroundColor: colors.tint + "18" },
              ]}
            >
              <Feather name="users" size={36} color={colors.tint} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.text }]}>
              {filter === "All" ? "No vendors yet" : `No ${filter} vendors`}
            </Text>
            <Text style={[styles.emptySub, { color: colors.textSecondary }]}>
              {filter === "All"
                ? "Tap the + tab to add your first vendor"
                : "Try a different category or add a new vendor"}
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <VendorCard
            vendor={item}
            onDelete={() => deleteVendor(item.id)}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingBottom: 16,
    gap: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 2,
    zIndex: 10,
  },
  headerTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    flex: 1,
  },
  countPill: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  countText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  filterRow: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    borderWidth: 1,
  },
  filterChipText: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  list: {
    padding: 16,
    gap: 12,
  },
  card: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 16,
    padding: 14,
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  typeIndicator: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  cardContent: {
    flex: 1,
    gap: 3,
  },
  vendorName: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flexWrap: "wrap",
  },
  typeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  typeBadgeText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  dateText: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
  },
  phoneText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 1,
  },
  cardActions: {
    gap: 8,
    alignItems: "center",
  },
  callButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
  },
  deleteButton: {
    width: 32,
    height: 32,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  empty: {
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 80,
    gap: 12,
  },
  emptyIconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: "Inter_600SemiBold",
  },
  emptySub: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 22,
    paddingHorizontal: 30,
  },
});
